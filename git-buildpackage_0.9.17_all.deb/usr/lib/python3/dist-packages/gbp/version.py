"The current gbp version number"
gbp_version = "0.9.17"
